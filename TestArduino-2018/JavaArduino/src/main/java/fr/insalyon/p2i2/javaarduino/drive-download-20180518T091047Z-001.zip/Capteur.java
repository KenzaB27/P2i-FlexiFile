
public class Capteur {
	
	private int idCapteur; 
	private int numSerie; 
	private int idGroupe; 
	private int position ; 
	
	public Capteur (int id, int num , int gr, int pos){
		idCapteur = id; 
		numSerie = num; 
		idGroupe = gr;
		position = pos;		
	}
	
	public int getIdCapteur(){
		return idCapteur;
	}
	
	public int getNumSerie(){
		return numSerie;
	}
	
	public int getIdGroupe(){
		return idGroupe;
	}
	
	public int getPos(){
		return position;
	}
}

