public class Groupe {
	
	private int idGroupe;
	private String nomGroupe;
	private int densite;
	public ArrayList<Capteur> listCapteur = new ArrayList<Capteur>();
	
	public Groupe(int id, String nom, int d){
		idGroupe = id;
		nomGroupe = nom;
		densite = d;
	}
	
	public int getIdGroupe(){
		return idGroupe;
	}
	
	public String getNom(){
		return nomGroupe;
	}
	
	public int getDensite(){
		return densite;
	}
}
		
