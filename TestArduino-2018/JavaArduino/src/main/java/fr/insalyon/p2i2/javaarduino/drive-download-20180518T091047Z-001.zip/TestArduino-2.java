package fr.insalyon.p2i2.javaarduino;

import fr.insalyon.p2i2.javaarduino.usb.ArduinoManager;
import fr.insalyon.p2i2.javaarduino.util.Console;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class TestArduino {
	
    private static Connection connection;
    public static void main(String[] args) {
        
    String bd = "G223_B_BD2";
	String login = "G223_B";
	String mdp = "G223_B";
	try {

            // Chargement de la classe du driver par le DriverManager
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver trouvé...");

            // Création d'une connexion sur la base de donnée
            connection = DriverManager.getConnection("jdbc:mysql://PC-TP-MYSQL.insa-lyon.fr:3306/" + bd, login, mdp);
            System.out.println("Connexion établie...");

        } catch (Exception e) {
            System.err.println(e.getMessage());
            System.exit(0);
        }
        // Objet matérialisant la console d'exécution (Affichage Écran / Lecture Clavier)
        final Console console = new Console();

        // Affichage sur la console
        console.log("DÉBUT du programme TestArduino");

        console.log("TOUS les Ports COM Virtuels:");
        for (String port : ArduinoManager.listVirtualComPorts()) {
            console.log(" - " + port);
        }
        console.log("----");

        // Recherche d'un port disponible (avec une liste d'exceptions si besoin)
        String myPort = ArduinoManager.searchVirtualComPort("COM0", "/dev/tty.usbserial-FTUS8LMO", "COM1", "COM2", "COM3");

        console.log("CONNEXION au port " + myPort);

        ArduinoManager arduino = new ArduinoManager(myPort) {
            @Override
            protected void onData(String line) {

                // Cette méthode est appelée AUTOMATIQUEMENT lorsque l'Arduino envoie des données
                // Affichage sur la Console de la ligne transmise par l'Arduino
                console.println("ARDUINO >> " + line);

                // À vous de jouer ;-)
                // Par exemple:
                //   String[] data = line.split(";");
                //   int sensorid = Integer.parseInt(data[0]);
                //   double value = Double.parseDouble(data[1]);
                //   ...
                
		String[] splitted = line.split(",");
				
		try {   
			//Creation de la requete
			
			String sqlStr = "INSERT INTO Mesure(idCapteur, dateMesure, valeur) VALUES (?,?,?)";
			PreparedStatement ps= connection.prepareStatement(sqlStr);
                        int idCapteur = Integer.parseInt(splitted[0]);
                        double valeur = Double.parseDouble(splitted[1]);
			long timestamp = Long.parseLong(splitted[2]);
				  
                        ps.setInt(1, 1);
                        java.sql.Date date = new java.sql.Date(timestamp * 1000);
                        DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
                        String text = df.format(date);
 
                        System.out.println("The date is: " + text);
                        ps.setDate(2, date);
			//ps.setTimestamp(2, new Timestamp(timestamp));
			ps.setDouble(3, valeur);
			//execution de la requete
			ps.executeUpdate();
		}
		catch(Exception e){
			//si une erreur se produit, affichage du message correspondant
			System.out.println(e.getMessage());
		}
            }
        };
        
        try {   
			//Creation de la requete
			
			sqlStr = "INSERT INTO File(longueur, tmpAttente, idGroupe, dateMesure) VALUES (?,?,?,?)";
			ps = connection.prepareStatement(sqlStr);
            int longueur = getLongueur();
            DateTime tmpAttente = getTmp();
			int idGroupe = getIdGroupe();             
			timestamp = getTime();
			
            ps.setInt(1, longueur);
            ps.setDateTime(2, tmpAttente);
            ps.setInt (3,idGroupe);
                
            date = new java.sql.Date(timestamp * 1000);        
            String text = df.format(date);
            
            ps.setDate(4, date);
            
			//execution de la requete
			ps.executeUpdate();
		}
		catch(Exception e){
			//si une erreur se produit, affichage du message correspondant
			System.out.println(e.getMessage());
		}
            }
        };

        try {

            console.log("DÉMARRAGE de la connexion");
            // Connexion à l'Arduino
            arduino.start();

            console.log("BOUCLE infinie en attente du Clavier");
            // Boucle d'ecriture sur l'arduino (execution concurrente au thread)
            boolean exit = false;

            while (!exit) {

                // Lecture Clavier de la ligne saisie par l'Utilisateur
                String line = console.readLine("Envoyer une ligne (ou 'stop') > ");

                if (line.length() != 0) {

                    // Affichage sur l'écran
                    console.log("CLAVIER >> " + line);

                    // Test de sortie de boucle
                    exit = line.equalsIgnoreCase("stop");

                    if (!exit) {
                        // Envoi sur l'Arduino du texte saisi au Clavier
                        arduino.write(line);
                    }
                }
            }

            console.log("ARRÊT de la connexion");
            // Fin de la connexion à l'Arduino
            arduino.stop();

        } catch (IOException ex) {
            // Si un problème a eu lieu...
            console.log(ex);
        }

    }
    
    public ArrayList getCapteur(String nomGroupe){ 
		try{
			String query = "select * from capteur, Groupe where idGroupe = ?";
			// Construction de l'objet « requête parametrée »
			PreparedStatement ps = conn.prepareStatement(query);
			// transformation en requête statique
			ps.setInt(1, 30) ; //remplacer le premier ? par la valeur 30
			ResultSet rs = ps.executeQuery();
			System.out.println ("Les locations sont :") ;
			System.out.println("Abonné | Vélo | Date | Durée”);
			while ( rs.next () ) {
				System.out.println (
				rs.getInt("IdAbonne") + " | " + rs.getInt("IdVelo") + " | " +
				rs.getDate("DateL") + " | " + rs.getint("duree") + " | ") ;
			}
			
			
			}
		}
}
